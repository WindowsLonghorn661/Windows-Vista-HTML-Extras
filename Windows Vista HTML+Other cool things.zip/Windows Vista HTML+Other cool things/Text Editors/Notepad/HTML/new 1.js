var fso = new ActiveXObject("Scripting.FileSystemObject");
var shell = new ActiveXObject("WScript.Shell");

// InputBox function (like prompt)
function inputBox(message, title, defaultText) {
    var hta = new ActiveXObject("MSHTA.Application");
    return hta.InputBox(message, title, defaultText);
}

var content = "";

// MENU
var choice = shell.Popup(
    "WSH Notepad\n\nYes = Open file\nNo = New file",
    0,
    "Notepad",
    36
);

// YES = Open file
if (choice == 6) {
    var path = inputBox("Enter file path:", "Open", "");

    if (path && fso.FileExists(path)) {
        var file = fso.OpenTextFile(path, 1);
        content = file.ReadAll();
        file.Close();
    } else {
        shell.Popup("File not found.");
    }
}

// EDIT LOOP
while (true) {
    var input = inputBox(
        "Edit text below.\n(Type END to finish and save)",
        "Editor",
        content
    );

    if (input === null || input === "END") break;

    content = input;
}

// SAVE
var savePath = inputBox("Save file as:", "Save", "output.txt");

if (savePath) {
    var file = fso.OpenTextFile(savePath, 2, true);
    file.Write(content);
    file.Close();
    shell.Popup("File saved!");
}